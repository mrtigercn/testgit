/** Automatically generated file. DO NOT MODIFY */
package com.taobao.top.android.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}