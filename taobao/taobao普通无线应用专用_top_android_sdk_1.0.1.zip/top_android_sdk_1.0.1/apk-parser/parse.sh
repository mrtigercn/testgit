#!/bin/bash

java -cp ./apk-parser.jar com.taobao.top.Parser $1
